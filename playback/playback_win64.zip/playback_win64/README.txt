This playback performs frame sync and extracts image/depth into a folder. 

Usage: 
Open Windows command prompt, and execute
    playback.exe  <ONI file>  <output folder>

Example: put 016.oni into the same folder with playback.exe and execute
    mkdir 016
    playback.exe  016.oni  016 
which will extract all image files from 016.oni to 016 folder. 

