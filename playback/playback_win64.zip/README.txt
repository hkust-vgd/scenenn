This playback performs frame sync and extracts image/depth into a folder. 
